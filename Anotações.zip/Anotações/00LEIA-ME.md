Anotações feitas usando o Obsidian. Feitas para estudo pessoal e também para ensinar a um amigo junto a linguagem C.

Pode não te agradar a forma com que eu faço as anotações, pode parecer coisa demais, porém é a forma que eu sempre fiz e funcionou para mim.